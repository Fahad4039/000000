# 3D Expense Tracker (Secure)

This is the secure version with Email+Password auth and RLS policies for Supabase.

Follow the guide in the project root to run locally and deploy.
